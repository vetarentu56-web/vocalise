const { app, BrowserWindow } = require('electron');
const { spawn } = require('child_process');
const path = require('path');

let mainWindow;
let pythonProcess = null;

function startPythonBackend() {
  // Path to the Python executable inside your .venv folder on Linux
  const pythonExecutable = path.join(__dirname, '.venv', 'bin', 'python');
  const scriptPath = path.join(__dirname, 'app.py');

  // Spawns the virtual environment's python instance
  pythonProcess = spawn(pythonExecutable, [scriptPath]);

  pythonProcess.stdout.on('data', (data) => {
    console.log(`[Python]: ${data}`);
  });

  pythonProcess.stderr.on('data', (data) => {
    console.error(`[Python Error]: ${data}`);
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    frame: false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
  });
  mainWindow.setAutoHideMenuBar(true);

  // Give your local server 1.5 seconds to bind to port 5000
  setTimeout(() => {
    mainWindow.loadURL('http://127.0.0.1:5000');
  }, 1500);
}

app.whenReady().then(() => {
  startPythonBackend();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (pythonProcess !== null) {
    pythonProcess.kill('SIGINT'); // Kills Python clean so the port doesn't lock up
  }
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
