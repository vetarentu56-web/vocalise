import os
import base64
import io
from pathlib import Path
from flask import Flask, request, jsonify, send_file, render_template
from gtts import gTTS

app = Flask(__name__)

@app.route('/')
def index():
    # Serves your HTML file (placed inside the 'templates' folder)
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate_audio():
    try:
        data = request.get_json()
        text = data.get('text', '').strip()
        tld = data.get('tld', 'com')

        if not text:
            return jsonify({'error': 'Text cannot be empty'}), 400

        # Generate audio using gTTS and save it directly into memory
        audio_buffer = io.BytesIO()
        tts = gTTS(text=text, lang='en', tld=tld, slow=False)
        tts.write_to_fp(audio_buffer)
        audio_buffer.seek(0)

        # Stream the audio file back to the client
        return send_file(
            audio_buffer, 
            mimetype='audio/mpeg', 
            as_attachment=False, 
            download_name='voice.mp3'
        )

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/save-audio', methods=['POST'])
def save_audio():
    try:
        data = request.get_json()
        if not data or 'audio_data' not in data:
            return jsonify({'error': 'No audio data received'}), 400

        # Decode the base64 string back into raw audio bytes
        audio_bytes = base64.b64decode(data['audio_data'])

        # Cross-platform safe path to the user's native OS Downloads folder
        downloads_path = str(Path.home() / "Downloads")
        file_name = "vocalise-speech.mp3"
        full_path = os.path.join(downloads_path, file_name)

        # Automatically increments file names if 'vocalise-speech.mp3' already exists
        counter = 1
        while os.path.exists(full_path):
            full_path = os.path.join(downloads_path, f"vocalise-speech ({counter}).mp3")
            counter += 1

        # Write the file directly to disk
        with open(full_path, 'wb') as f:
            f.write(audio_bytes)

        return jsonify({'status': 'success', 'path': full_path}), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
